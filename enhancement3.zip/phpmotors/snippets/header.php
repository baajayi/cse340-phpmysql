<header class="header"> <img src="/phpmotors/images/site/logo.png" alt="php motors logo">
    <span class="account"><a href="/phpmotors/accounts/?action=login">My Account</a></span>
   </header>