<header class="header"> <img src="/phpmotors/images/site/logo.png" alt="php motors logo">
    <span class="account"><a href="#">My Account</a></span>
   </header>