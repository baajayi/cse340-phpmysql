    <footer class="footer">
        <p>&copy;PHP Motors, All Rights Reserved. 
            <br>All images used are believed to be in "Fair Use". Please notify the author if any are not and they will be removed.
            <br>
            <?php
        $cusTime = '2023-01-12';
        $date = new DateTime($cusTime);
        $_REQUEST["date"] = $date->format('j F, Y');
        echo 'Last updated: ';
        echo $_REQUEST["date"];
        ?>
    </footer>
