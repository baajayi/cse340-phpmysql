
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Vehicle | PHP Motors</title>
    <link rel="stylesheet" href="/phpmotors/css/template.css">
</head>
<body>
 <div id="wrapper">
 <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
     <nav>
        <?php 
     //require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'; 
     echo $navList; ?>
     </nav>
<main>
<h2>Add a Vehicle</h2>
<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="POST" action="/phpmotors/vehicles/index.php">
   <label for="invMake">Make</label>
   <input type="text" name="invMake" id="invMake">
   <label for="invModel">Model</label>
   <input type="text" name="invModel" id="invModel">
   <label for="invDescription">Description</label>
   <input type="text" name="invDescription" id="invDescription">
   <label for="invImage">Image Path</label>
   <input type="text" name="invImage" value="/images/no-image.png" id="invImage">
   <label for="invThumbnail">Thumbnail</label>
   <input type="text" name="invThumbnail" value="/images/no-image.png" id="invThumbnail">
   <label for="invPrice">Price</label>
   <input type="number" name="invPrice" id="invPrice">
   <label for="invColor">Color</label>
   <input type="text" name="invColor" id="invColor">
   <?php
    echo $classificationList;
    ?>
   
   
   <input type="submit" name="submit" id="regbtn" value="Add Vehicle">
        
    <input type="hidden" name="action" value="vehicle">
</form>
</main>
<hr>
<?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/snippets/footer.php'; ?>   

    </div>
</body>
</html>