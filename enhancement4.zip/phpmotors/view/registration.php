<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | PHP Motors</title>
    <link rel="stylesheet" href="/phpmotors/css/template.css">
</head>
<body>
<div id="wrapper">
 <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
     <nav>
        <?php 
     //require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/nav.php'; 
     echo $navList; ?>
     </nav>
<main>
<h2>Registration Page</h2>
<?php
if (isset($message)) {
 echo $message;
}
?>
<form method="post" action="/phpmotors/accounts/index.php">
    <fieldset>
        <legend>Personal Details</legend>
        <label for="firstname">First name: <input type="text" name="clientFirstname" id="firstname" placeholder="first name" ></label>
        <label for="lastname">Last name: <input type="text" name="clientLastname" id="lastname" placeholder="last name" ></label>
        <label for="email">Email: <input type="email" name="clientEmail" id="email" placeholder="name@example.com" ></label>
        <label for="password">Password:
            <input type="password" name="clientPassword" placeholder="Password"  id="password">
        </label>
        <input type="submit" name="submit" id="regbtn" value="Register">
        
        <input type="hidden" name="action" value="register">
        <p>Already registered? <a href="/phpmotors/accounts/?action=login">Login</a></p>
    </fieldset>
</form>
</main>
<hr>
<?php require $_SERVER['DOCUMENT_ROOT'].'/phpmotors/snippets/footer.php'; ?>   

    </div>
</body>
</html>