    <footer class="footer">
        <p>&copy;PHP Motors, All Rights Reserved. 
            <br>All images used are believed to be in "Fair Use". Please notify the author if any are not and they will be removed.
            <br>
            <p>Last updated: <?php echo date("F d, Y", filemtime(__FILE__)); ?></p>

    </footer>
